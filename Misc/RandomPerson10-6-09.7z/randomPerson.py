######################### Random Person Generator ###################################
#########################    by Nick Mellor       ###################################
#########################     Version 1.0         ###################################
#########################      June 2009          ###################################
"""Random Personal Data Generator
Generates random personal data: name, sex, birthdate, address, web address,
email address etc. based on an existing contact list and name popularity data.

The existing contact list is randomised and obfuscated in various ways, so that
an ordinary contact list can be dropped into the random person generator unchanged--
you should be able to use your own address  book.

Additional data about a person can be passed through from the contact list or
the name frequency tables, e.g. job title, notes, favourite sport, spouse name.

Using this method a relatively large number of random names and addresses
can be generated from quite a small initial contacts list.

Currently, obfuscations include:
  - all numbers in first line of address are changed
  - names are randomised (popularity-adjusted)
  - web addresses are decoupled from postal addresses
  - usernames and emails are regenerated
  - birthdays are randomised (realistically)"""

from math import exp
import random
import os
import csv
import re
import hashlib

class RandomName:
    """Returns a random (atomic) name based on a name popularity lookup table.
    Can be used for surnames, middle names and forenames.
    More common names are returned more frequently."""
        
    def __init__(self, filename, namefield="Name"):
        self.filename = filename
        self.namefield = namefield
        namelist = csv.DictReader(open(filename))
        self.runningtotal_field = "rn_runningTotal"
        self.namepopularity_field = "Common5"
        runningTotal = 0.0
        # Weed out rows with blank name field (e.g. empty lines at end of file)
        self.namelist = [k for k in namelist if k[namefield] != ""]
        for k in self.namelist:
            # self.namepopularity_field from 0-5. Weight name popularity exponentially
            weight = exp(float(k[self.namepopularity_field]))
            # runningTotal is value that selects this name
            runningTotal += weight
            k[self.runningtotal_field] = runningTotal

    def name_only(self):
        return self.all_name_data()[self.namefield]

    def all_name_data(self):
        """ returns all data in the name file row for that name """
        # total weight (of all names) is the running total
        # of the last element of the name list
        totalWeight = self.namelist[-1][self.runningtotal_field]
        # pick a number in the weight range
        r = random.uniform(0.0, totalWeight)
        # find name with closest running total
        # relatively inefficient linear search O(n)
        for k in self.namelist:
            if r <= k[self.runningtotal_field]: return k
        # if still haven't found something, something's wrong
        return {}


class RandomPerson:
    
    def __init__(self):
        self.nameroot = r"N:\Internal Projects\Testing\Packages\RandomPerson"
        self.firstlineofaddress_field = "Street"
        self.website_field = "Website"
        self.forename = RandomName(self.resolve_filename("Forenames.csv"), \
                                   namefield="Forename")
        self.surname = RandomName(self.resolve_filename("Surnames.csv"), \
                                  namefield="Surname")
        self.randomAddress = self.address(self.resolve_filename("Addresses.csv"))
        self.fieldorder = []

    def resolve_filename(self, filename):
        return os.path.join(self.nameroot, filename)

    def address(self, filename):
        "generator returning a random address"
        # store field order from original address table-- used by output functions
        self.fieldorder = csv.reader(open(filename)).next()
        # load in whole list for speed
        addresses = list(csv.DictReader(open(filename)))
        while True:
            k = dict.copy(random.choice(addresses))
            k[self.website_field] = \
                        random.choice(addresses)[self.website_field]
            yield k
        
    def name_and_sex(self):
        """ return forename, surname and sex only.
        All other data (if any) dropped"""
        forenameData = self.forename.all_name_data()
        return  {
            "First name" : forenameData["Forename"],
            "Sex"      : forenameData["Sex"],
            "Last Name"  : self.surname.name_only()
                }
        
    def new_person(self):
        """generator returning random but realistic personal data:
        name, sex, address, username, password, birthday, email,
        website etc. Data is modelled on an existing
        address list and name frequency tables, with various fields
        obfuscated for privacy. Is a generator in case people need
        numbering"""
        # May use id counter for generating usernames, emails etc
        id = 1
        while True:
            person = {}
            # Add address info to person
            person.update(self.randomAddress.next())
            ### Disguise address-- change all numbers
            # First randomise numbers in first line of address (Outlook contacts CSV export format)
            firstline = re.split("(^[0-9]+)", person[self.firstlineofaddress_field])
            # If no numbers in address, leave as is
            if len(firstline) != 1:
                # Replace all numbers with random no in 1..5 (Level, flat etc.)
                for el in firstline:
                    if el.isdigit(): el = str(random.randint(1,5))
                if firstline[0] == "":
                    # Initial number: choose from larger range for house numbers, including odd and even
                    firstline[1] = str(int(random.randint(0,75) * 3 + 1))
            person[self.firstlineofaddress_field] = "".join(firstline)
            # Override (if already present in address data) or insert surname and forename info
            person.update(self.name_and_sex())
            ### Generate fake email addresses, usernames and ids
            # Simple username: unique per run
            #username = "test" + str(id)
            # Sophisticated username: good uniqueness across
            # multiple runs.
            # (removing [:5] gives mathematically near-perfect
            # uniqueness but long usernames.)
            username = person["First name"] + "-" \
                       + hashlib.md5(repr(person)).hexdigest()[:5]
            # Use username for email as well
            person.update({"Email" : username + "@bendigotraders.org",
                           "username" : username,
                           "password" : "test"})
            # Birthday
            person["Birthday"] = self.new_birthday()
            yield person
            id += 1
            
    def new_birthday(self):
        """Return random birthdays (string, dd/mm/yyyy). Attempts to distribute birthdays realistically."""
        # Normal Distribution by default
        # See http://en.wikipedia.org/wiki/Median_age for population models
        birthyear = int(random.normalvariate(1960, 15))
        birthmonth = random.randint(1, 12)
        monthlen = (31,28,31,30,31,30,31,31,30,31,30,31)
        lastdayofmonth = monthlen[birthmonth - 1]
        # take leap year into account
        if (birthmonth == 2
         and birthyear%4 == 0
         and (birthyear%100 != 0 or birthyear%400 == 0)):
            lastdayofmonth = 29
        birthday = int(random.uniform(1,31) * (float(lastdayofmonth)/31) + 1.0)
        return "%d/%d/%d" % (birthday, birthmonth, birthyear)

    def generate_people_file(self, n, output_filename="generatednames.csv"):
        """write a file of random people"""
        outputfile = file(os.path.join(self.nameroot, output_filename), "wb")
        np = self.new_person()
        personfields = list(np.next().keys())
        wtr = csv.DictWriter(outputfile, self.fieldorder, extrasaction='ignore')
        # Write heading row in order of original contacts table
        # (kludge: dictionary of self-filled keys for a dictwriter)
        wtr.writerow(dict(zip(self.fieldorder, self.fieldorder)))
        # Write people data
        for i in range(n):
            wtr.writerow(np.next())
        outputfile.close()
                           
if __name__ == "__main__":
    generate_file = True
    if generate_file:
        RandomPerson().generate_people_file(600)
    else:
        newGeezer = RandomPerson().new_person()
        justnames = True
        for i in range(10):
            p = newGeezer.next()
            if not(justnames):
                print
                print "=================================="
            print p["Last Name"], p["First name"], p["Sex"]
            if not(justnames):
                print "=================================="
                print
                for j in p.items():
                   print "%s: %s" % (j[0], j[1])