# NameGen.py
# generates names (surnames, forenames) using weightings to ensure more
# common names appear more often

# Input: csv lists of names with frequency factor 0-5 (sorting unnecessary)
# input files can contain other fields, in any order, which are ignored
# A heading row is assumed, but not used

# model: Names have "common5" frequency factor (0=rare, 5=common)
# Script assumes common names (common5==5) occur e**5 times for every 1 time a rare name appears,
# i.e. about 150:1

# Method: compute running total for each name (its own weighted score added to the weighted scores
# of all names before it in the list) then map a uniform random number to the
# running totals list and return the name matched

import os.path
# exp is used for weighting model
from math import exp
import random

# folder containing name data
scriptPath = "h:\\Testing\\NameDb"

def rawLines(filename):
    """returns raw data rows as a list"""
    return [rawLine.strip("\n")
               for rawLine
               in file(os.path.join(scriptPath, filename))]

def dictify(rawlist, delim, fieldnames):
    """takes a list of raw lines and separates fields into dictionary entries at
    delimiter 'delim', fieldnames in 'fieldnames'"""
    li = [dict(zip(fieldnames, k.split(delim)))
                    for k
                    in rawlist
                    if k.split(delim)[0] != ""]
    # remove first line (assumed to be a heading)
    del li[0]
    return li

def loadSurnames(filename):
    return dictify(rawLines(filename), ",", ("Name", "Common5"))

def loadForenames(filename):
    return dictify(rawLines(filename), ",", ("Name", "Sex", "Common5"))

def weightedList(li):
    """produces list of name/running total tuples based on a weighting model.
    When a random number lands on a name's running total in chooseNameByWeight
    that name is returned. Names are currently weighted by e**Common5"""
    nameData = [(k["Name"], exp(float(k["Common5"])))
                 for k
                 in li]
    runningTotal = 0.0
    runningTotals = []
    for k in nameData:
        runningTotal += k[1]
        runningTotals.append(runningTotal)
    # Return (name, runningTotal) pairs as a list
    return zip([k[0] for k in nameData], runningTotals)

def chooseNameByWeight(weightedList):
    # total weight (of all names) is the running total
    # of the last element of the name list
    totalWeight = weightedList[-1][1]
    # pick a uniformly-distributed number in the total weight range
    r = random.uniform(0.0, totalWeight)
    # find name with closest running total
    # (relatively inefficient linear search O(n) might impact e.g. load testing)
    for k in weightedList:
        if r <= k[1]: return k[0]
    return "None"
        
        

if __name__ == "__main__":
    _surnames = loadSurnames("surnames.csv")
    _forenames = loadForenames("forenames.csv")
    forenames = weightedList(_forenames)
    #print forenames
    surnames = weightedList(_surnames)
    #print surnames
    for r in range(10):
        print chooseNameByWeight(surnames) + ", " + chooseNameByWeight(forenames)