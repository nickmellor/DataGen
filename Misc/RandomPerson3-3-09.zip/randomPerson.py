from math import exp, floor
from dictfile import dictfile
import random

class RandomName:
    """return a random (atomic) name. More common names are returned more frequently.
    Uses a list of names (with frequencies) to generate a stream of random names"""
    def __init__(self, filename, namefield = "Name"):
        self.filename = filename
        self.namefield = namefield
        namelist = dictfile(filename).nextrow()
        runningTotal = 0.0
        self._runningTotals = []
        for k in namelist:
            weight = exp(float(k["Common5"]))
            runningTotal += weight
            self._runningTotals.append((k[namefield], runningTotal))

    def randomByWeight(self):
        # total weight (of all names) is the running total
        # of the last element of the name list
        totalWeight = self._runningTotals[-1][1]
        # pick a uniformly-distributed number in the weight range
        r = random.uniform(0.0, totalWeight)
        # find name with closest running total
        # (relatively inefficient linear search O(n) might impact e.g. load testing)
        for k in self._runningTotals:
            if r <= k[1]: return k[0]
        # if still haven't found something, something's wrong
        return "None"

class RandomPerson:
    def __init__(self):
        self.forename = RandomName("h:\\Testing\\NameDb\\Forenames.csv", namefield = "Forename")
        self.surname = RandomName("h:\\Testing\\NameDb\\Surnames.csv", namefield = "Surname")
        self.randomAddress = dictfile("h:\\Testing\\NameDb\\Addresses.csv").cycleShuffled()


    

    def randomName(self):
        return {"Forename" : self.forename.randomByWeight(),
                "Surname" : self.surname.randomByWeight()}
        
    def createNewPerson(self):
        while 1:
            person = {}
            # add address info to person
            person.update(self.randomAddress.next())
            # override (if already present in address data) or insert surname and forename info
            person.update(self.randomName())
            # Birthday (make an attempt to distribute them around realistic ages for TMS)
            person["Birthday"] = randomBirthday()
            yield person

def randomBirthday():
        # my assumptions about when Damien's customers were born
        birthyear = int(random.normalvariate(1960, 15))
        birthmonth = random.randint(1, 12)
        monthlen = (31,28,31,30,31,30,31,31,30,31,30,31)
        lastdayofmonth = monthlen[birthmonth - 1]
        # take leap year into account
        if birthmonth==2 and birthyear%4 == 0: lastdayofmonth = 29
        birthday = int(random.uniform(1,31) * (float(lastdayofmonth)/31) + 1.0)
        return "%d/%d/%d" % (birthday, birthmonth, birthyear)
    
if __name__ == "__main__":
    rp = RandomPerson().createNewPerson()
    for i in range(200): print rp.next()