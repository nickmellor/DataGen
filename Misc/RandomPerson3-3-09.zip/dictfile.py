import random

class dictfile:
    """reads delimited text files (e.g. CSVs) and stores fields in dictionaries. Allows code like:
        if employee["forename"]=="Nick": ...
    instead of:
        if employee[3]=="Nick": ...
    Also can be selective (e.g. only pull 2 fields out of a table of 119 cols)"""
    
    def __init__(self,filename, fieldnames = "", delim = ","):
        # optionally specify delimeter and field names
        self._filename = filename
        self._delim = delim
        # fieldnames is a visible member of dictfile
        # if initially blank, then class assumes all fields are needed
        self.fieldnames = fieldnames

    def nextrow(self):
        """returns the next row in dict form. Memory-efficient and fast for large files.
        Optionally only returns specified fields"""
        f = file(self._filename)
        # clean up heading names and put in a tuple
        fileheadings = tuple(f.readline().strip("\n").split(self._delim))
        if self.fieldnames=="":
            self.fieldnames = fileheadings
            # note generator (in "in" expression, yield)
            for row in (rawLine.strip("\n")
                    for rawLine
                    in f
                    if rawLine.split(self._delim)[0] != ""):
                yield dict(zip(self.fieldnames, row.split(self._delim)))
        else:
            # need to delete some columns from output
            for row in (rawLine.strip("\n")
                    for rawLine
                    in f):
                # build new dict with only specified columns (assume very few cols usually wanted
                # from large files)
                retdic = {}
                rowfields = dict(zip(fileheadings, row.split(self._delim)))
                # skip a blank line
                if rowfields[self.fieldnames[0]]=="": continue
                for thisfield in self.fieldnames:
                    retdic[thisfield] = rowfields[thisfield]
                yield retdic

    def cycleOrdered(self):
        "endlessly cycle through input file in order-- small files only, fast"
        sequence = list(self.nextrow())
        while 1:            
            for k in sequence: yield k

    def cycleShuffled(self):
        "endlessly cycles through a shuffled version of input file-- small files only, fast"
        sequence = list(self.nextrow())
        while 1:
            random.shuffle(sequence)
            for k in sequence: yield k
